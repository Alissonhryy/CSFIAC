# CSF Manager - Sistema de Gestão de Cursos

Sistema web completo para gerenciamento de cursos, instrutores e alunos com interface moderna e responsiva.

## Funcionalidades

- **Dashboard**: Visão geral com KPIs e cards de cursos
- **Calendário**: Visualização de cursos por data
- **Instrutores**: Gestão completa de instrutores
- **Usuários**: Gerenciamento de usuários com diferentes níveis de acesso (Admin, Editor, Visualizador)
- **Importação/Exportação**: Suporte para arquivos Excel (.xlsx, .xls) e CSV
- **Relatórios**: Geração de relatórios com gráficos e exportação em imagem

## Tecnologias

- HTML5, CSS3, JavaScript
- Firebase Firestore (opcional - funciona também com localStorage)
- Chart.js para gráficos
- SheetJS para importação de planilhas
- html2canvas para exportação de relatórios

## Como Usar

### Opção 1: GitHub Pages (Recomendado)

1. Faça um fork deste repositório ou clone para sua conta
2. Vá em **Settings** > **Pages**
3. Em "Source", selecione **Deploy from a branch**
4. Selecione a branch `main` e pasta `/ (root)`
5. Clique em **Save**
6. Aguarde alguns minutos e acesse pelo link gerado

### Opção 2: Hospedagem Local

1. Clone o repositório:
   \`\`\`bash
   git clone https://github.com/seu-usuario/csf-manager.git
   \`\`\`
2. Abra o arquivo `index.html` no navegador

### Opção 3: Outros Serviços

O projeto funciona em qualquer serviço de hospedagem estática:
- Vercel
- Netlify
- Firebase Hosting

## Credenciais Padrão

| Usuário | Senha | Função |
|---------|-------|--------|
| admin | admin123 | Administrador |
| editor | editor123 | Editor |
| viewer | viewer123 | Visualizador |

⚠️ **Importante**: Altere as credenciais padrão após o primeiro acesso!

## Estrutura de Dados

### Cursos
- Nome do Curso
- ID da Turma / Lote
- Carga Horária (20H, 40H, 60H)
- Cidade / Local
- Período (Início - Fim)
- Status (Pendente, Em Andamento, Concluído, Cancelado)
- Instrutor
- Concludentes
- Link do Google Drive
- Anotações

### Instrutores
- Nome
- Especialidade
- Telefone
- Email

## Importação de Planilhas

O sistema aceita planilhas Excel com as seguintes colunas:

| Coluna | Descrição |
|--------|-----------|
| CURSO | Nome do curso |
| ID | ID da turma |
| LOTE-RESPONSÁVEL | Lote ou responsável |
| CARGA HORÁRIA | 20H, 40H ou 60H |
| CIDADE/MUNICÍPIO | Cidade do curso |
| INÍCIO | Data de início |
| FIM | Data de término |
| CONCLUDENTES | Número de alunos |
| LOCAL DO CURSO | Local específico |
| INSTRUTOR | Nome do instrutor |
| STATUS | Status do curso |
| GOOGLE DRIVE | Link da pasta |
| OBSERVAÇÃO | Anotações |

## Persistência de Dados

- **Com Firebase**: Os dados são sincronizados em tempo real na nuvem
- **Sem Firebase**: Os dados são salvos no localStorage do navegador

## Licença

Este projeto está sob a licença MIT.
